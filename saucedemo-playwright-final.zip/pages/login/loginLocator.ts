export const loginLocators = {
  usernameField: '#user-name',
  passwordField: '#password',
  loginButton: '#login-button',
  errorMessage: '[data-test="error"]'
};
